package com.thinktubekorea.menu;

public class ItemSub {

    private String name;
    private String price;
    private int image;

    public ItemSub(String name, String tel, int image) {
        this.name = name;
        this.price = price;
        this.image = image;
    }

    public ItemSub(String[] str_item, String[] str_price, Integer image) {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTel() {
        return price;
    }

    public void setTel(String tel) {
        this.price = price;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }
}